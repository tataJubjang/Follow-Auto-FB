<?php
function e7061($e){
	$ed = base64_decode($e);
	$n = openssl_decrypt("$ed","AES-256-CBC","3826362616266363",0,"3726584927271736");
	return $n;
}
?>
